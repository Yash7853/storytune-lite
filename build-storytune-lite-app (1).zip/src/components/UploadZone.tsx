import { useState, useRef, useCallback } from 'react';
import { Upload, ImagePlus } from 'lucide-react';

interface UploadZoneProps {
  onFileSelect: (file: File) => void;
}

export function UploadZone({ onFileSelect }: UploadZoneProps) {
  const [isDragOver, setIsDragOver] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFile = useCallback((file: File) => {
    if (file.type.startsWith('image/')) {
      onFileSelect(file);
    }
  }, [onFileSelect]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);

    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  }, [handleFile]);

  const handleClick = () => inputRef.current?.click();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  };

  return (
    <div
      className={`
        relative w-full max-w-md mx-auto rounded-2xl border-2 border-dashed
        transition-all duration-300 ease-out cursor-pointer
        ${isDragOver
          ? 'border-purple-500 bg-purple-500/10 scale-[1.02]'
          : 'border-gray-700 bg-dark-800/50 hover:border-purple-500/50 hover:bg-dark-800'
        }
      `}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      onClick={handleClick}
    >
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleInputChange}
      />

      <div className="flex flex-col items-center justify-center py-16 px-6">
        {/* Animated icon */}
        <div className={`
          w-20 h-20 rounded-full flex items-center justify-center mb-6
          transition-all duration-300
          ${isDragOver
            ? 'bg-purple-500/20 scale-110'
            : 'bg-gradient-to-br from-purple-500/10 to-pink-500/10'
          }
        `}>
          {isDragOver ? (
            <ImagePlus className="w-10 h-10 text-purple-400 animate-bounce" />
          ) : (
            <Upload className="w-10 h-10 text-gray-400" />
          )}
        </div>

        <h3 className="text-lg font-semibold text-white mb-2">
          {isDragOver ? 'Drop your photo here!' : 'Upload a Photo'}
        </h3>
        <p className="text-sm text-gray-500 text-center mb-4">
          Drag & drop or tap to select
        </p>
        <div className="flex items-center gap-2 text-xs text-gray-600">
          <span className="px-2 py-1 rounded bg-dark-700">JPG</span>
          <span className="px-2 py-1 rounded bg-dark-700">PNG</span>
          <span className="px-2 py-1 rounded bg-dark-700">WEBP</span>
        </div>
      </div>

      {/* Corner accent */}
      <div className="absolute top-0 left-0 w-16 h-16 overflow-hidden rounded-tl-2xl pointer-events-none">
        <div className="absolute -top-8 -left-8 w-16 h-16 bg-gradient-to-br from-purple-500/20 to-transparent rotate-45" />
      </div>
    </div>
  );
}
