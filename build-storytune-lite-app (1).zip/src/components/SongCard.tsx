import { useState, useRef, useEffect, useCallback } from 'react';
import { Play, Pause } from 'lucide-react';
import type { Song } from '../utils/songSearch';

interface SongCardProps {
  song: Song;
  isPlaying: boolean;
  onPlay: () => void;
  delay: number;
}

export function SongCard({ song, isPlaying, onPlay, delay }: SongCardProps) {
  const audioRef = useRef<HTMLAudioElement>(null);
  const [progress, setProgress] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [, setDuration] = useState(30);
  const [isLoading, setIsLoading] = useState(false);
  const [hasError, setHasError] = useState(false);
  const progressRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      setIsLoading(true);
      audio.play().then(() => setIsLoading(false)).catch(() => {
        setIsLoading(false);
        setHasError(true);
      });
    } else {
      audio.pause();
      setIsLoading(false);
    }
  }, [isPlaying]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleTimeUpdate = () => {
      const pct = (audio.currentTime / (audio.duration || 30)) * 100;
      setProgress(pct);
      setCurrentTime(audio.currentTime);
    };

    const handleLoadedMetadata = () => {
      setDuration(audio.duration || 30);
    };

    const handleEnded = () => {
      setProgress(0);
      setCurrentTime(0);
      onPlay(); // Toggle off
    };

    const handleError = () => {
      setHasError(true);
      setIsLoading(false);
    };

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('error', handleError);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('error', handleError);
    };
  }, [onPlay]);

  const handleProgressClick = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    const audio = audioRef.current;
    const bar = progressRef.current;
    if (!audio || !bar || hasError) return;

    const rect = bar.getBoundingClientRect();
    const pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    audio.currentTime = pct * (audio.duration || 30);
    setProgress(pct * 100);
  }, [hasError]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div
      className="animate-fade-in-up"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className={`
        group relative flex items-center gap-4 p-3 rounded-xl
        bg-dark-800/80 backdrop-blur-sm border transition-all duration-300
        ${isPlaying
          ? 'border-purple-500/40 bg-dark-700/80 shadow-lg shadow-purple-500/10'
          : 'border-gray-800/50 hover:border-gray-700 hover:bg-dark-700/50'
        }
      `}>
        {/* Audio element */}
        <audio ref={audioRef} src={song.previewUrl} preload="none" />

        {/* Thumbnail */}
        <div className="relative flex-shrink-0 w-14 h-14 rounded-lg overflow-hidden bg-dark-700">
          {song.thumbnail ? (
            <img
              src={song.thumbnail}
              alt={song.title}
              className="w-full h-full object-cover"
              loading="lazy"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-gray-600">
              ♪
            </div>
          )}

          {/* Play overlay */}
          <button
            onClick={onPlay}
            disabled={hasError}
            className={`
              absolute inset-0 flex items-center justify-center
              bg-black/40 transition-all duration-200
              ${hasError ? 'opacity-60 cursor-not-allowed' : 'opacity-0 group-hover:opacity-100'}
              ${isPlaying ? '!opacity-100 !bg-black/50' : ''}
            `}
          >
            {isLoading ? (
              <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : isPlaying ? (
              <Pause className="w-6 h-6 text-white" fill="white" />
            ) : (
              <Play className="w-6 h-6 text-white" fill="white" />
            )}
          </button>
        </div>

        {/* Song info + progress */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 mb-1">
            <div className="min-w-0">
              <p className="text-sm font-medium text-white truncate">
                {song.title}
              </p>
              <p className="text-xs text-gray-500 truncate">
                {song.artist}
              </p>
            </div>

            {/* Waveform animation */}
            {isPlaying && !hasError && (
              <div className="flex items-center gap-[3px] flex-shrink-0 mt-1">
                <div className="waveform-bar w-[3px] bg-purple-500 rounded-full" />
                <div className="waveform-bar w-[3px] bg-purple-400 rounded-full" />
                <div className="waveform-bar w-[3px] bg-pink-500 rounded-full" />
                <div className="waveform-bar w-[3px] bg-purple-400 rounded-full" />
                <div className="waveform-bar w-[3px] bg-purple-500 rounded-full" />
              </div>
            )}
          </div>

          {/* Progress bar */}
          {!hasError && (
            <div className="flex items-center gap-2">
              <span className="text-[10px] text-gray-600 w-8 text-right tabular-nums">
                {formatTime(currentTime)}
              </span>
              <div
                ref={progressRef}
                className="flex-1 h-1 bg-dark-600 rounded-full cursor-pointer group/progress relative"
                onClick={handleProgressClick}
              >
                <div
                  className="absolute top-0 left-0 h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full transition-[width] duration-100"
                  style={{ width: `${progress}%` }}
                />
                <div
                  className="absolute top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full shadow-lg opacity-0 group-hover/progress:opacity-100 transition-opacity"
                  style={{ left: `${progress}%`, marginLeft: '-6px' }}
                />
              </div>
              <span className="text-[10px] text-gray-600 w-8 tabular-nums">
                0:30
              </span>
            </div>
          )}

          {hasError && (
            <p className="text-[10px] text-red-400/70 mt-1">Preview unavailable</p>
          )}
        </div>

        {/* Language tag */}
        <div className={`
          flex-shrink-0 px-2 py-0.5 rounded text-[9px] font-semibold uppercase tracking-wider
          ${song.language === 'telugu'
            ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
            : 'bg-orange-500/10 text-orange-400 border border-orange-500/20'
          }
        `}>
          {song.language}
        </div>
      </div>
    </div>
  );
}
