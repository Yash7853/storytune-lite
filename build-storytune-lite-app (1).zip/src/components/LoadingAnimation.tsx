import { useEffect, useState } from 'react';
import { Music, Camera, Sparkles, Disc3 } from 'lucide-react';

const messages = [
  'Scanning your photo...',
  'Detecting colors & mood...',
  'Analyzing the vibe...',
  'Finding perfect songs...',
  'Almost there...',
];

export function LoadingAnimation() {
  const [messageIndex, setMessageIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setMessageIndex(prev => (prev + 1) % messages.length);
    }, 1500);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col items-center justify-center py-12 animate-fade-in">
      {/* Spinning disc */}
      <div className="relative w-24 h-24 mb-8">
        {/* Outer ring */}
        <div className="absolute inset-0 rounded-full border-2 border-purple-500/20 animate-spin-slow" />

        {/* Middle ring */}
        <div className="absolute inset-2 rounded-full border border-pink-500/20 animate-spin-slow" style={{ animationDirection: 'reverse', animationDuration: '2s' }} />

        {/* Inner disc */}
        <div className="absolute inset-4 rounded-full bg-gradient-to-br from-purple-600/30 to-pink-600/30 flex items-center justify-center animate-spin-slow" style={{ animationDuration: '4s' }}>
          <Disc3 className="w-8 h-8 text-purple-400" />
        </div>

        {/* Pulse rings */}
        <div className="absolute inset-0 rounded-full border border-purple-500/30" style={{ animation: 'analyze-pulse 2s ease-out infinite' }} />
        <div className="absolute inset-0 rounded-full border border-pink-500/30" style={{ animation: 'analyze-pulse 2s ease-out infinite 0.5s' }} />
      </div>

      {/* Icons orbit */}
      <div className="flex items-center gap-4 mb-6">
        <Camera className="w-5 h-5 text-blue-400 animate-float" />
        <Sparkles className="w-5 h-5 text-purple-400 animate-float" style={{ animationDelay: '0.3s' }} />
        <Music className="w-5 h-5 text-pink-400 animate-float" style={{ animationDelay: '0.6s' }} />
      </div>

      {/* Status message */}
      <div className="h-6 overflow-hidden">
        <p
          key={messageIndex}
          className="text-sm text-gray-400 animate-fade-in text-center"
        >
          {messages[messageIndex]}
        </p>
      </div>

      {/* Progress dots */}
      <div className="flex items-center gap-1.5 mt-4">
        {[0, 1, 2, 3, 4].map((i) => (
          <div
            key={i}
            className={`w-1.5 h-1.5 rounded-full transition-colors duration-300 ${
              i <= messageIndex ? 'bg-purple-500' : 'bg-gray-700'
            }`}
          />
        ))}
      </div>
    </div>
  );
}
