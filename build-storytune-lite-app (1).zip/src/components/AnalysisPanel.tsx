import type { AnalysisResult } from '../utils/imageAnalyzer';
import { getMoodEmoji, getSceneEmoji, getVibeEmoji } from '../utils/moodMapping';

interface AnalysisPanelProps {
  analysis: AnalysisResult;
}

const moodColors: Record<string, string> = {
  happy: 'from-yellow-500/20 to-orange-500/20 border-yellow-500/30 text-yellow-300',
  sad: 'from-blue-500/20 to-cyan-500/20 border-blue-500/30 text-blue-300',
  romantic: 'from-pink-500/20 to-rose-500/20 border-pink-500/30 text-pink-300',
  energetic: 'from-red-500/20 to-orange-500/20 border-red-500/30 text-red-300',
};

const sceneColors: Record<string, string> = {
  beach: 'from-cyan-500/20 to-blue-500/20 border-cyan-500/30 text-cyan-300',
  gym: 'from-red-500/20 to-orange-500/20 border-red-500/30 text-orange-300',
  street: 'from-gray-500/20 to-slate-500/20 border-gray-500/30 text-gray-300',
  home: 'from-amber-500/20 to-yellow-500/20 border-amber-500/30 text-amber-300',
  travel: 'from-green-500/20 to-emerald-500/20 border-green-500/30 text-green-300',
  night: 'from-indigo-500/20 to-purple-500/20 border-indigo-500/30 text-indigo-300',
};

const vibeColors: Record<string, string> = {
  aesthetic: 'from-violet-500/20 to-fuchsia-500/20 border-violet-500/30 text-violet-300',
  mass: 'from-red-500/20 to-amber-500/20 border-red-500/30 text-red-300',
  chill: 'from-teal-500/20 to-sky-500/20 border-teal-500/30 text-teal-300',
  emotional: 'from-purple-500/20 to-pink-500/20 border-purple-500/30 text-purple-300',
};

export function AnalysisPanel({ analysis }: AnalysisPanelProps) {
  const { mood, scene, vibe, confidence } = analysis;

  const tags = [
    { label: mood, emoji: getMoodEmoji(mood), color: moodColors[mood] },
    { label: scene, emoji: getSceneEmoji(scene), color: sceneColors[scene] },
    { label: vibe, emoji: getVibeEmoji(vibe), color: vibeColors[vibe] },
  ];

  return (
    <div className="animate-fade-in-up w-full max-w-md mx-auto">
      {/* Confidence bar */}
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs text-gray-500 uppercase tracking-wider font-medium">
          Detected Mood
        </span>
        <span className="text-xs text-gray-500">
          {confidence}% match
        </span>
      </div>

      {/* Tags */}
      <div className="flex items-center gap-2 flex-wrap mb-4">
        {tags.map((tag) => (
          <span
            key={tag.label}
            className={`
              inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full
              bg-gradient-to-r border text-sm font-medium
              ${tag.color}
            `}
          >
            <span>{tag.emoji}</span>
            <span className="capitalize">{tag.label}</span>
          </span>
        ))}
      </div>

      {/* Color palette */}
      <div className="flex items-center gap-2 mb-2">
        <span className="text-xs text-gray-600">Palette</span>
        <div className="flex items-center gap-1">
          {analysis.dominantColors.slice(0, 5).map((color, i) => (
            <div
              key={i}
              className="w-5 h-5 rounded-full border border-gray-700/50"
              style={{ backgroundColor: color }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
