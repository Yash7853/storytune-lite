import { useState, useCallback, useRef, useEffect } from 'react';
import { UploadZone } from './components/UploadZone';
import { SongCard } from './components/SongCard';
import { AnalysisPanel } from './components/AnalysisPanel';
import { LoadingAnimation } from './components/LoadingAnimation';
import { analyzeImage } from './utils/imageAnalyzer';
import type { AnalysisResult } from './utils/imageAnalyzer';
import { searchSongs } from './utils/songSearch';
import type { Song } from './utils/songSearch';
import { RotateCcw, Sparkles, Music2, Upload, ChevronDown } from 'lucide-react';

type AppState = 'upload' | 'preview' | 'analyzing' | 'results';

export default function App() {
  const [appState, setAppState] = useState<AppState>('upload');
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [songs, setSongs] = useState<Song[]>([]);
  const [currentlyPlaying, setCurrentlyPlaying] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const resultsRef = useRef<HTMLDivElement>(null);

  // Cleanup object URLs
  useEffect(() => {
    return () => {
      if (imagePreview) URL.revokeObjectURL(imagePreview);
    };
  }, []);

  const handleFileSelect = useCallback((file: File) => {
    if (imagePreview) URL.revokeObjectURL(imagePreview);
    const url = URL.createObjectURL(file);
    setUploadedFile(file);
    setImagePreview(url);
    setAppState('preview');
    setAnalysis(null);
    setSongs([]);
    setError(null);
    setCurrentlyPlaying(null);
  }, [imagePreview]);

  const handleAnalyze = useCallback(async () => {
    if (!uploadedFile) return;

    setAppState('analyzing');
    setError(null);
    setCurrentlyPlaying(null);

    // Add a small delay for better UX
    await new Promise(r => setTimeout(r, 500));

    try {
      const result = await analyzeImage(uploadedFile);
      setAnalysis(result);

      // Small delay before fetching songs
      await new Promise(r => setTimeout(r, 300));

      const songResults = await searchSongs(result);
      if (songResults.length === 0) {
        setError('No matching songs found. Try a different photo!');
      }
      setSongs(songResults);
      setAppState('results');
    } catch {
      setError('Something went wrong. Please try again.');
      setAppState('preview');
    }
  }, [uploadedFile]);

  const handlePlay = useCallback((songId: string) => {
    setCurrentlyPlaying(prev => prev === songId ? null : songId);
  }, []);

  const handleReset = useCallback(() => {
    if (imagePreview) URL.revokeObjectURL(imagePreview);
    setUploadedFile(null);
    setImagePreview(null);
    setAnalysis(null);
    setSongs([]);
    setError(null);
    setCurrentlyPlaying(null);
    setAppState('upload');
  }, [imagePreview]);

  // Scroll to results when they appear
  useEffect(() => {
    if (appState === 'results' && resultsRef.current) {
      setTimeout(() => {
        resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 300);
    }
  }, [appState]);

  return (
    <div className="min-h-screen bg-dark-900 text-white selection:bg-purple-500/30">
      {/* Background gradient orbs */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-600/5 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-pink-600/5 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-indigo-600/3 rounded-full blur-3xl" />
      </div>

      {/* Header */}
      <header className="relative z-10 pt-8 pb-4 px-4">
        <div className="max-w-lg mx-auto text-center">
          {/* Logo */}
          <div className="inline-flex items-center gap-2 mb-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center shadow-lg shadow-purple-500/20">
              <Music2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold gradient-text leading-tight">
                StoryTune
              </h1>
              <p className="text-[10px] text-gray-500 uppercase tracking-[0.2em] -mt-0.5">
                Lite
              </p>
            </div>
          </div>

          <p className="text-sm text-gray-500 max-w-xs mx-auto">
            Upload a photo & discover the perfect soundtrack
          </p>
        </div>
      </header>

      {/* Main content */}
      <main className="relative z-10 px-4 pb-16 max-w-lg mx-auto">
        {/* Upload state */}
        {appState === 'upload' && (
          <div className="mt-8 animate-fade-in">
            <UploadZone onFileSelect={handleFileSelect} />

            {/* How it works */}
            <div className="mt-10 space-y-3">
              <p className="text-xs text-gray-600 text-center uppercase tracking-wider font-medium">
                How it works
              </p>
              <div className="grid grid-cols-3 gap-3">
                {[
                  { icon: Upload, label: 'Upload', desc: 'Pick a photo' },
                  { icon: Sparkles, label: 'Analyze', desc: 'AI detects mood' },
                  { icon: Music2, label: 'Discover', desc: 'Get your songs' },
                ].map(({ icon: Icon, label, desc }) => (
                  <div
                    key={label}
                    className="flex flex-col items-center gap-1.5 p-3 rounded-xl bg-dark-800/40 border border-gray-800/30"
                  >
                    <Icon className="w-5 h-5 text-purple-400" />
                    <span className="text-xs font-medium text-gray-300">{label}</span>
                    <span className="text-[10px] text-gray-600">{desc}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Preview + Analyze state */}
        {(appState === 'preview' || appState === 'analyzing' || appState === 'results') && imagePreview && (
          <div className="mt-6">
            {/* Image preview card */}
            <div className="relative rounded-2xl overflow-hidden bg-dark-800 border border-gray-800/50 shadow-2xl">
              <img
                src={imagePreview}
                alt="Uploaded photo"
                className="w-full max-h-72 object-cover"
              />

              {/* Gradient overlay at bottom */}
              <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-dark-900 to-transparent" />

              {/* Reset button */}
              <button
                onClick={handleReset}
                className="absolute top-3 right-3 w-9 h-9 rounded-full bg-black/50 backdrop-blur-md border border-white/10 flex items-center justify-center hover:bg-black/70 transition-colors"
                title="Start over"
              >
                <RotateCcw className="w-4 h-4 text-white/80" />
              </button>
            </div>

            {/* Analyze button */}
            {appState === 'preview' && (
              <div className="mt-6 animate-fade-in-up">
                <button
                  onClick={handleAnalyze}
                  className="w-full py-4 rounded-xl font-semibold text-white
                    bg-gradient-to-r from-purple-600 to-pink-600
                    hover:from-purple-500 hover:to-pink-500
                    active:scale-[0.98]
                    transition-all duration-200
                    shadow-lg shadow-purple-500/25
                    flex items-center justify-center gap-2
                    animate-pulse-glow"
                >
                  <Sparkles className="w-5 h-5" />
                  Analyze Photo
                </button>

                <p className="text-[11px] text-gray-600 text-center mt-3">
                  AI will detect mood, scene & vibe from your photo
                </p>
              </div>
            )}

            {/* Loading state */}
            {appState === 'analyzing' && (
              <LoadingAnimation />
            )}
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="mt-4 p-4 rounded-xl bg-red-500/10 border border-red-500/20 animate-fade-in">
            <p className="text-sm text-red-400 text-center">{error}</p>
            {appState === 'preview' && (
              <button
                onClick={handleAnalyze}
                className="mt-3 w-full py-2 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-sm hover:bg-red-500/20 transition-colors"
              >
                Try Again
              </button>
            )}
          </div>
        )}

        {/* Results */}
        {appState === 'results' && analysis && (
          <div ref={resultsRef} className="mt-8">
            {/* Analysis panel */}
            <AnalysisPanel analysis={analysis} />

            {/* Divider */}
            <div className="flex items-center gap-3 my-6">
              <div className="flex-1 h-px bg-gradient-to-r from-transparent via-gray-800 to-transparent" />
              <div className="flex items-center gap-1.5 text-xs text-gray-500">
                <Music2 className="w-3.5 h-3.5" />
                <span>Your Soundtrack</span>
              </div>
              <div className="flex-1 h-px bg-gradient-to-r from-transparent via-gray-800 to-transparent" />
            </div>

            {/* Song cards */}
            {songs.length > 0 && (
              <div className="space-y-2">
                {songs.map((song, index) => (
                  <SongCard
                    key={song.id}
                    song={song}
                    isPlaying={currentlyPlaying === song.id}
                    onPlay={() => handlePlay(song.id)}
                    delay={index * 80}
                  />
                ))}
              </div>
            )}

            {/* Analyze another button */}
            <div className="mt-8 text-center">
              <button
                onClick={handleReset}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl
                  bg-dark-800 border border-gray-800 text-gray-400
                  hover:text-white hover:border-gray-700 hover:bg-dark-700
                  transition-all duration-200 text-sm"
              >
                <RotateCcw className="w-4 h-4" />
                Analyze Another Photo
              </button>
            </div>
          </div>
        )}

        {/* Scroll hint on preview */}
        {appState === 'results' && (
          <div className="fixed bottom-4 right-4 animate-bounce opacity-30 pointer-events-none">
            <ChevronDown className="w-5 h-5 text-gray-500" />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="relative z-10 pb-6 text-center">
        <p className="text-[10px] text-gray-700">
          Powered by AI color analysis & iTunes previews
        </p>
      </footer>
    </div>
  );
}
